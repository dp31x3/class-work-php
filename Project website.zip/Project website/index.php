<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Taberna do Cacador</title>
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Amatic+SC" />
    <link rel="stylesheet" href="menu.css">
</head>
        
    <body>
        <img align="right" src="logo.jpg" alt="logo" width="20%" height="50%">
        <br>
            <a href="index.php" class="topheader">PÁGINA INICIAL</a>
            <br>
            <a href="menu.html" class="topheader">MENU</a>
            <br>
            <a href="sobre.html" class="topheader">SOBRE A TABERNA</a>
            <br>
            <a href="menufds.html" class="topheader">MENU DE FIM DE SEMANA</a>
            <br>
            <a href="contactos.html" class="topheader">CONTACTOS</a>

        <div class="footer">        
            <a href="https://www.facebook.com/tabernacacador/" target="_blank"><p>Siga-nos no Facebook</p></a>
        </div>
    </body>    
</html>

